# ariac_group-2
*****Team Members*****
1. Aryan Mishra- 120426049
2. Gautam Sreenarayanan Nair - 119543092
3. Hitesh Kyatham - 120275364
4. Keyur Borad - 120426049
5. Sarin Ann Mathew - 119390382
**************************************
******Instructions to run*************
1. Run the following command in terminal-1
ros2 launch ariac_gazebo ariac.launch.py trial_name:=rwa3_spring2024

2. Run the following command in terminal-2
ros2 launch rwa3_group_2 rwa3.launch.py

   
